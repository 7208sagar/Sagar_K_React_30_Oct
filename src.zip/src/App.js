import logo from './logo.svg';
import './App.css';
import CounterND from './component/CounterND';
// import Counter from './component/Counter';


function App() {
  return (
    <div>
      {/* <Counter/> */}
      <CounterND />
    </div>
  );
}

export default App;
